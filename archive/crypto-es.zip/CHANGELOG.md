## 1.2.2

**2020-02-21**

- Fix guides for TypeScript usage.

## 1.2.1

**2020-01-23**

- Add guides for TypeScript usage.

## 1.2.0

**2020-01-09**

- Add types for TypeScript usage.
- Update license to 2020.

## 1.1.1

**2019-07-15**

- Remove loader.mjs, insead using package.json type field for ECMAScript Modules.
- Update README.md.

## 1.1.0

**2019-07-12**

- Add support for ArrayBuffer and TypedArray.
- Change some inner object names in case of confusion for partially import. 

## 1.0.2

**2019-01-20**

- Update README.md.

## 1.0.1

**2019-01-19**

- Add keywords.

## 1.0.0

**2019-01-19**

- Initial version.
- Impliment all CryptoJS APIs.
